
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { FurnitureConfig, FurnitureType } from './types';

export const GRID_SIZE = 12;
export const TICK_RATE_MS = 3000;
export const INITIAL_BUDGET = 5000; // Tăng ngân sách khởi đầu một chút vì có nhiều đồ hơn

export const FURNITURE: Record<FurnitureType, FurnitureConfig> = {
  [FurnitureType.None]: {
    type: FurnitureType.None,
    cost: 0,
    name: 'Remove',
    description: 'Remove item.',
    color: '#ef4444',
    styleGen: 0,
    comfortGen: 0,
  },
  [FurnitureType.Flooring]: {
    type: FurnitureType.Flooring,
    cost: 50,
    name: 'Rug',
    description: 'Soft texture.',
    color: '#d4a373',
    styleGen: 5,
    comfortGen: 2,
  },
  [FurnitureType.Seating]: {
    type: FurnitureType.Seating,
    cost: 400,
    name: 'Sofa',
    description: 'Modern comfort.',
    color: '#7f5539',
    styleGen: 15,
    comfortGen: 25,
  },
  [FurnitureType.Table]: {
    type: FurnitureType.Table,
    cost: 200,
    name: 'Table',
    description: 'Coffee table.',
    color: '#9c6644',
    styleGen: 8,
    comfortGen: 5,
  },
  [FurnitureType.LargeTable]: {
    type: FurnitureType.LargeTable,
    cost: 450,
    name: 'Dinning',
    description: 'Large family table.',
    color: '#8b5a2b',
    styleGen: 12,
    comfortGen: 10,
  },
  [FurnitureType.Bed]: {
    type: FurnitureType.Bed,
    cost: 800,
    name: 'Bed',
    description: 'Luxury sleep.',
    color: '#b7b7a4',
    styleGen: 20,
    comfortGen: 50,
  },
  [FurnitureType.Storage]: {
    type: FurnitureType.Storage,
    cost: 300,
    name: 'Cabinet',
    description: 'Storage unit.',
    color: '#6b705c',
    styleGen: 10,
    comfortGen: 0,
  },
  [FurnitureType.Bookshelf]: {
    type: FurnitureType.Bookshelf,
    cost: 550,
    name: 'Library',
    description: 'Tall bookshelf.',
    color: '#3d405b',
    styleGen: 25,
    comfortGen: 5,
  },
  [FurnitureType.Electronics]: {
    type: FurnitureType.Electronics,
    cost: 1200,
    name: 'TV Set',
    description: 'Entertainment system.',
    color: '#2d2d2d',
    styleGen: 40,
    comfortGen: 15,
  },
  [FurnitureType.Decor]: {
    type: FurnitureType.Decor,
    cost: 150,
    name: 'Plant',
    description: 'Green touch.',
    color: '#588157',
    styleGen: 30,
    comfortGen: 0,
  },
  [FurnitureType.Wall]: {
    type: FurnitureType.Wall,
    cost: 100,
    name: 'Wall',
    description: 'Division.',
    color: '#e5e5e5',
    styleGen: 2,
    comfortGen: 0,
  },
  [FurnitureType.Window]: {
    type: FurnitureType.Window,
    cost: 350,
    name: 'Window',
    description: 'Natural light.',
    color: '#a2d2ff',
    styleGen: 20,
    comfortGen: 5,
  },
  [FurnitureType.Door]: {
    type: FurnitureType.Door,
    cost: 400,
    name: 'Door',
    description: 'Entrance.',
    color: '#5e3023',
    styleGen: 10,
    comfortGen: 0,
  },
};
