
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Grid, TileData, FurnitureType, HomeStats, AIDesignGoal, MagazineSnippet } from './types';
import { GRID_SIZE, FURNITURE, TICK_RATE_MS, INITIAL_BUDGET } from './constants';
import IsoMap from './components/IsoMap';
import UIOverlay from './components/UIOverlay';
import StartScreen from './components/StartScreen';
import { generateOfflineQuest, generateLocalMagazineSnippet } from './services/localQuestService';
import { generateDesignGoal, generateMagazineSnippet } from './services/geminiService';

const createInitialGrid = (): Grid => {
  const grid: Grid = [];
  for (let y = 0; y < GRID_SIZE; y++) {
    const row: TileData[] = [];
    for (let x = 0; x < GRID_SIZE; x++) {
      row.push({ x, y, furnitureType: FurnitureType.None });
    }
    grid.push(row);
  }
  return grid;
};

function App() {
  const [gameStarted, setGameStarted] = useState(false);
  const [aiEnabled, setAiEnabled] = useState(true);
  const [grid, setGrid] = useState<Grid>(createInitialGrid);
  const [stats, setStats] = useState<HomeStats>({ budget: INITIAL_BUDGET, stylePoints: 0, phase: 1 });
  const [selectedTool, setSelectedTool] = useState<FurnitureType>(FurnitureType.Seating);
  const [currentGoal, setCurrentGoal] = useState<AIDesignGoal | null>(null);
  const [isGeneratingGoal, setIsGeneratingGoal] = useState(false);
  const [newsFeed, setNewsFeed] = useState<MagazineSnippet[]>([]);
  const [aiError, setAiError] = useState<string | null>(null);
  
  const gridRef = useRef(grid);
  const statsRef = useRef(stats);
  const goalRef = useRef(currentGoal);

  useEffect(() => { gridRef.current = grid; }, [grid]);
  useEffect(() => { statsRef.current = stats; }, [stats]);
  useEffect(() => { goalRef.current = currentGoal; }, [currentGoal]);

  const fetchNewGoal = useCallback(async () => {
    if (isGeneratingGoal || currentGoal) return;
    setIsGeneratingGoal(true);
    
    try {
      let nextGoal: AIDesignGoal | null = null;
      
      if (aiEnabled) {
        nextGoal = await generateDesignGoal(statsRef.current, gridRef.current);
      }

      if (!nextGoal) {
        // Fallback to local quest
        const quest = generateOfflineQuest(statsRef.current);
        nextGoal = {
          description: quest.description,
          targetType: quest.targetType,
          targetValue: quest.targetValue,
          furnitureType: quest.furnitureType,
          reward: quest.reward,
          completed: false
        };
      }

      setCurrentGoal(nextGoal);
      setAiError(null);
    } catch (err) {
      console.error("Goal fetch failed:", err);
      setAiError("Designer is briefly unavailable.");
    } finally {
      setIsGeneratingGoal(false);
    }
  }, [isGeneratingGoal, currentGoal, aiEnabled]);

  const fetchNews = useCallback(async () => {
    if (Math.random() > 0.05) return; 
    try {
      let news: MagazineSnippet | null = null;
      if (aiEnabled) {
        news = await generateMagazineSnippet(statsRef.current);
      }
      
      if (!news) {
        news = await generateLocalMagazineSnippet();
      }
      
      if (news) setNewsFeed(prev => [...prev.slice(-10), news]);
    } catch (err) {}
  }, [aiEnabled]);

  useEffect(() => {
    if (!gameStarted) return;
    if (!currentGoal && !isGeneratingGoal) {
      const timer = setTimeout(fetchNewGoal, 1000);
      return () => clearTimeout(timer);
    }
  }, [gameStarted, currentGoal, fetchNewGoal, isGeneratingGoal]);

  useEffect(() => {
    if (!gameStarted) return;
    const intervalId = setInterval(() => {
      let totalStyle = 0;
      const counts: Record<string, number> = {};
      gridRef.current.flat().forEach(tile => {
        if (tile.furnitureType !== FurnitureType.None) {
          totalStyle += FURNITURE[tile.furnitureType].styleGen;
          counts[tile.furnitureType] = (counts[tile.furnitureType] || 0) + 1;
        }
      });

      setStats(prev => {
        const nextStats = { ...prev, stylePoints: totalStyle };
        const goal = goalRef.current;
        if (goal && !goal.completed) {
          let met = false;
          if (goal.targetType === 'style' && totalStyle >= goal.targetValue) met = true;
          if (goal.targetType === 'budget' && nextStats.budget >= goal.targetValue) met = true;
          if (goal.targetType === 'furniture_count' && goal.furnitureType && (counts[goal.furnitureType] || 0) >= goal.targetValue) met = true;
          if (met) setCurrentGoal({ ...goal, completed: true });
        }
        return nextStats;
      });

      fetchNews();
    }, TICK_RATE_MS);
    return () => clearInterval(intervalId);
  }, [gameStarted, fetchNews]);

  const handleTileClick = useCallback((x: number, y: number) => {
    const tool = selectedTool;
    const currentTile = gridRef.current[y][x];
    
    if (tool === FurnitureType.None) {
      if (currentTile.furnitureType !== FurnitureType.None) {
        const refundAmount = FURNITURE[currentTile.furnitureType].cost;
        setStats(prev => ({ ...prev, budget: prev.budget + refundAmount }));
        
        const newGrid = gridRef.current.map(row => [...row]);
        newGrid[y][x] = { ...currentTile, furnitureType: FurnitureType.None };
        setGrid(newGrid);
      }
      return;
    }

    if (currentTile.furnitureType === FurnitureType.None && statsRef.current.budget >= FURNITURE[tool].cost) {
      setStats(prev => ({ ...prev, budget: prev.budget - FURNITURE[tool].cost }));
      const newGrid = gridRef.current.map(row => [...row]);
      newGrid[y][x] = { ...currentTile, furnitureType: tool };
      setGrid(newGrid);
    }
  }, [selectedTool]);

  const handleClaimReward = () => {
    if (currentGoal?.completed) {
      setStats(prev => ({ ...prev, budget: prev.budget + currentGoal.reward, phase: prev.phase + 1 }));
      setCurrentGoal(null);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0f172a]">
      <IsoMap grid={grid} onTileClick={handleTileClick} hoveredTool={selectedTool} />
      {!gameStarted && <StartScreen onStart={(enabled) => { setAiEnabled(enabled); setGameStarted(true); }} />}
      {gameStarted && (
        <UIOverlay 
          stats={stats} 
          selectedTool={selectedTool} 
          onSelectTool={setSelectedTool} 
          currentGoal={currentGoal} 
          newsFeed={newsFeed} 
          onClaimReward={handleClaimReward} 
          isGeneratingGoal={isGeneratingGoal} 
          aiEnabled={aiEnabled}
          aiError={aiError}
          onRetryGoal={() => { fetchNewGoal(); }}
        />
      )}
    </div>
  );
}

export default App;
