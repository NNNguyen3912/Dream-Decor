
import { HomeStats, MagazineSnippet, FurnitureType } from "../types";

export interface GameQuest {
  id: string;
  title: string;
  description: string;
  reward: number;
  targetType: 'style' | 'budget' | 'furniture_count';
  targetValue: number;
  furnitureType?: FurnitureType;
}

const pickRandom = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

export const generateOfflineQuest = (stats: HomeStats): GameQuest => {
  const questType = Math.floor(Math.random() * 3);
  const id = `quest_${Date.now()}`;
  const multiplier = Math.max(1, Math.floor(stats.phase / 2));

  if (questType === 0) {
    const targets = [
      { type: FurnitureType.Seating, name: "modern Sofas", val: 2 },
      { type: FurnitureType.LargeTable, name: "dining tables", val: 1 },
      { type: FurnitureType.Electronics, name: "entertainment units", val: 1 },
      { type: FurnitureType.Bookshelf, name: "bookshelves", val: 2 },
      { type: FurnitureType.Window, name: "bright windows", val: 3 },
      { type: FurnitureType.Wall, name: "solid walls", val: 4 },
      { type: FurnitureType.Decor, name: "artistic plants", val: 3 },
    ];
    const selected = pickRandom(targets);
    return {
      id,
      title: "Design Specialist",
      description: `Incorporate at least ${selected.val} ${selected.name} into your layout.`,
      reward: 250 * multiplier,
      targetType: 'furniture_count',
      targetValue: selected.val,
      furnitureType: selected.type
    };
  }

  if (questType === 1) {
    const targetBudget = stats.budget + (1500 * multiplier);
    return {
      id,
      title: "Wealth Management",
      description: `Reach a total budget of $${targetBudget.toLocaleString()} to upgrade your studio.`,
      reward: 400 * multiplier,
      targetType: 'budget',
      targetValue: targetBudget
    };
  }

  const targetStyle = stats.stylePoints + (80 * multiplier);
  return {
    id,
    title: "Vogue Architect",
    description: `Elevate the room's aesthetic until your Style Score reaches ${targetStyle}.`,
    reward: 350 * multiplier,
    targetType: 'style',
    targetValue: targetStyle
  };
};

const SNIPPETS = [
    { text: "Smart TV sets are becoming the focal point of modern living rooms.", type: 'trend' },
    { text: "Natural light from large windows can boost your style score significantly.", type: 'tip' },
    { text: "A bookshelf isn't just for books; it's a statement piece.", type: 'trend' },
    { text: "Try grouping your seating around a large dining table for a social vibe.", type: 'tip' },
    { text: "Empty walls feel cold. Use windows or decor to break the monotony.", type: 'critique' },
    { text: "The industrial look of exposed walls is making a huge comeback.", type: 'trend' }
];

export const generateLocalMagazineSnippet = async (): Promise<MagazineSnippet> => {
    const randomSnippet = pickRandom(SNIPPETS);
    return {
        id: Math.random().toString(36).substr(2, 9),
        text: randomSnippet.text,
        type: randomSnippet.type as any
    };
};
