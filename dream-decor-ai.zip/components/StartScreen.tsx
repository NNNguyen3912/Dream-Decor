
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';

interface StartScreenProps {
  onStart: (aiEnabled: boolean) => void;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  const [aiEnabled, setAiEnabled] = useState(true);

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center z-50 text-white font-sans p-6 bg-slate-900/60 backdrop-blur-md">
      <div className="max-w-md w-full bg-slate-800 p-10 rounded-[2.5rem] border border-slate-700 shadow-2xl relative overflow-hidden">
        {/* Abstract blueprint lines decor */}
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'linear-gradient(#475569 1px, transparent 1px), linear-gradient(90deg, #475569 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        </div>

        <div className="relative z-10 text-center">
            <h1 className="text-4xl font-black mb-1 text-sky-400 tracking-tight">
            Dream Decor AI
            </h1>
            <p className="text-slate-400 mb-8 text-xs font-bold uppercase tracking-widest">
            Studio Interior Planning
            </p>

            <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-700 mb-8">
            <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex flex-col gap-1 text-left">
                <span className="font-bold text-slate-200">Design Consultant</span>
                <span className="text-[10px] text-slate-500">Enable Gemini AI for creative advice.</span>
                </div>
                <input type="checkbox" className="sr-only peer" checked={aiEnabled} onChange={(e) => setAiEnabled(e.target.checked)} />
                <div className="w-10 h-6 bg-slate-700 rounded-full peer-checked:bg-sky-500 relative transition-colors after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-4"></div>
            </label>
            </div>

            <button onClick={() => onStart(aiEnabled)} className="w-full py-4 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-2xl shadow-lg transition-all active:scale-95 text-lg">
            Start Designing
            </button>
        </div>
      </div>
    </div>
  );
};

export default StartScreen;
